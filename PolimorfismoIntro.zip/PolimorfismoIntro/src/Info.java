public interface Info {
    String getInfo();
}
